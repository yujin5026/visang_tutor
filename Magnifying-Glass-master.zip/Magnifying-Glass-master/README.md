# Magnifying-Glass

## DEMO1
마우스 움직임에 따라 이미지를 확대한다.
https://saintsilver.github.io/Magnifying-Glass/

## DEMO2
마우스 움직임에 따라 돋보기 모양 내 이미지만 확대한다. (원본이미지크기 기반)
https://saintsilver.github.io/Magnifying-Glass/index2.html

## DEMO3
마우스 움직임에 따라 돋보기 모양 내 이미지만 확대한다. (배율 설정)
https://saintsilver.github.io/Magnifying-Glass/index3.html